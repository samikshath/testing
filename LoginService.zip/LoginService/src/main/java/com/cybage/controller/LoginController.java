package com.cybage.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.ResponseErrorHandler;
import org.springframework.web.client.RestTemplate;
import com.cybage.exception.CustomException;
import com.cybage.model.User;

@CrossOrigin("*")
@RestController
public class LoginController {
	@Autowired
	private RestTemplate restTemplate;

	@PostMapping("/registration")
	public ResponseEntity<String> registration(@RequestBody User user) {
		String url = "http://localhost:8080/food-delivery/register";
		restTemplate.postForEntity(url, user, String.class);
		return new ResponseEntity<String>("Added successfully", HttpStatus.ACCEPTED);
	}

	@PostMapping("/login")
	public ResponseEntity<?> userLogin(@RequestBody User user) throws CustomException {
		String url = "http://localhost:8080/food-delivery/login";
		String userDetails="";
		try {
			userDetails = restTemplate.postForEntity(url, user, String.class).getBody();
			return new ResponseEntity<String>(userDetails, HttpStatus.OK);
		} catch (Exception exception) {
			userDetails=exception.getMessage();
		}
		throw new CustomException(userDetails);
	}

}
