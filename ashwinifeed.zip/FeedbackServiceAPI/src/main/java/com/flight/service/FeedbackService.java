package com.flight.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.flight.pojo.Feedback;
import com.flight.repository.FeedbackRepository;

@Service
public class FeedbackService {

	@Autowired
	FeedbackRepository feedbackRepository;
	
	
	public List<Feedback> getAllFeedbacks(){
		return feedbackRepository.findAll();
	}
	
	public Feedback addFeedback(Feedback feedback) {
			
	  return feedbackRepository.save(feedback);
	}
}
