package com.flight.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.flight.pojo.Feedback;
import com.flight.service.FeedbackService;

@CrossOrigin("*")
@RestController
@RequestMapping("/feedback")
public class FeedbackController {
	
	@Autowired
	FeedbackService feedbackService;
	
	@GetMapping("/getAllFeedback")
	public List<Feedback> getAllFeedback(){
		return feedbackService.getAllFeedbacks();
	}
	
	
	@PostMapping("/addFeedback")
	public Feedback addFeedbacks(@RequestBody Feedback feedback) {
		
		return feedbackService.addFeedback(feedback);
	}
	
	

}
