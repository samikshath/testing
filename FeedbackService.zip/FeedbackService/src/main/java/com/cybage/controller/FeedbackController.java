package com.cybage.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;
import com.cybage.exception.CustomException;
import com.cybage.model.Feedback;

@CrossOrigin("http://localhost:3000")
@RestController
public class FeedbackController {
	@Autowired
	private RestTemplate restTemplate;

	@PostMapping("/addFeedback")
	public ResponseEntity<?> userLogin(@RequestBody Feedback feedback) throws CustomException {
		String url = "http://localhost:8080/feedback/addFeedback";
		String feedbackDetails = restTemplate.postForEntity(url, feedback, String.class).getBody();
			return new ResponseEntity<String>(feedbackDetails, HttpStatus.OK);
	}

	@GetMapping("/allFeedback")
	public ResponseEntity<?> getAllFeedback() throws CustomException {
		String url = "http://localhost:8080/feedback/";
		 Feedback[] feedbackDetails = restTemplate.getForEntity(url, Feedback[].class).getBody();
			return new ResponseEntity<>(feedbackDetails, HttpStatus.OK);
	}
}
