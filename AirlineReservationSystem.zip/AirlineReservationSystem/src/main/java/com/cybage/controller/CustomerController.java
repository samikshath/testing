package com.cybage.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.cybage.model.Customer;

import com.cybage.service.CustomerService;

@CrossOrigin("*")
@RequestMapping("/signup")
@RestController
public class CustomerController {

	@Autowired
	CustomerService customerService;
	
	@PostMapping("/")
	public ResponseEntity<String> addUser(@RequestBody Customer customer)
	{
		customerService.addUser(customer);
		return new ResponseEntity<String>("record added successfully",HttpStatus.CREATED);
	}
	
	@GetMapping("/")
	public ResponseEntity<List<Customer>>  getAllTutorial()

	{
		//List<Customer> customer=customerService.showAll();
		return  new ResponseEntity<List<Customer>>(customerService.showAll(),HttpStatus.OK);		
			
	}
	
}
