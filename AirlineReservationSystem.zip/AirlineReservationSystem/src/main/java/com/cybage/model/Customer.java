package com.cybage.model;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.validation.constraints.Email;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Pattern;
import javax.validation.constraints.Size;


@Entity
public class Customer {
	
	@Id
	@GeneratedValue
	private int CustId;
	
	@NotNull
	private String userName;
	
	
	@Pattern(regexp="^[0-9]{10}$") //The annotated CharSequence must match the specified regular expression
	private String contactNo;
	
	@Email //The string has to be a well-formed email address
	@NotNull
	private String email;
	
	@NotNull
	private int age;
	
	@NotNull
	private String gender;
	
	@NotNull
	@Size(min = 8)	//The annotated element size must be between the specified boundaries (included). 
	private String password;

	public Customer() {
		super();
	}

	public Customer(int custId, @NotNull String userName, @Pattern(regexp = "^[0-9]{10}$") String contactNo,
			@Email @NotNull String email, @NotNull int age, @NotNull String gender,
			@NotNull @Size(min = 8) String password) {
		super();
		CustId = custId;
		this.userName = userName;
		this.contactNo = contactNo;
		this.email = email;
		this.age = age;
		this.gender = gender;
		this.password = password;
	}

	public int getCustId() {
		return CustId;
	}

	public void setCustId(int custId) {
		CustId = custId;
	}

	public String getUserName() {
		return userName;
	}

	public void setUserName(String userName) {
		this.userName = userName;
	}

	public String getContactNo() {
		return contactNo;
	}

	public void setContactNo(String contactNo) {
		this.contactNo = contactNo;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public int getAge() {
		return age;
	}

	public void setAge(int age) {
		this.age = age;
	}

	public String getGender() {
		return gender;
	}

	public void setGender(String gender) {
		this.gender = gender;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	@Override
	public String toString() {
		return "Customer [CustId=" + CustId + ", userName=" + userName + ", contactNo=" + contactNo + ", email=" + email
				+ ", age=" + age + ", gender=" + gender + ", password=" + password + "]";
	}

	
	
	
}
