package com.cybage.service;

import java.util.List;
import com.cybage.model.Cart;

public interface CartService {
    public List<Cart> getAllCartItems();
}
