package com.cybage;

import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.domain.EntityScan;
import org.springframework.boot.autoconfigure.security.servlet.SecurityAutoConfiguration;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;

import java.io.File;
import java.io.FileOutputStream;
import java.time.LocalTime;
import java.util.Arrays;
import java.util.Calendar;
import java.util.Map;
import java.util.Set;
import java.util.TreeMap;

import com.cybage.controller.UserComplaintController;
import com.cybage.service.EmailSenderService;
import com.cybage.service.ExportService;
import com.cybage.service.SendSms;
import com.cybage.service.SmsService;
import com.cybage.service.SmsServiceTwilio;


@SpringBootApplication(scanBasePackages = "com.cybage")
@EnableJpaRepositories(basePackages = "com.cybage.dao")
@EntityScan(basePackages = "com.cybage.model")
@EnableAutoConfiguration(exclude = SecurityAutoConfiguration.class)
public class FoodDeliveryAppApplication implements CommandLineRunner {
	@Autowired
	private EmailSenderService senderService;

	@Autowired
	private ExportService export;

	@Override
	public void run(String... args) throws Exception {
//		senderService.sendOTP("rajanisa@cybage.com");

		//senderService.sendEmail("pushpakdh@cybage.com");
		

//		senderService.sendEmail("preranab@cybage.com","123");

		//new SendSms().sendSms("Order","8087722043");

		// export.printUser();


	}
	public static void main(String[] args) {
		SpringApplication.run(FoodDeliveryAppApplication.class, args);

		// LocalTime myObj = LocalTime.now();
		// String[] charac = myObj.toString().split(".");

        // System.out.println(Arrays.toString(charac));
		
		// excel sheet

	// 	HSSFWorkbook workbook = new HSSFWorkbook(); 
       
    //    //Create a blank sheet
    //    HSSFSheet sheet = workbook.createSheet("Employee Data");
         
    //    //This data needs to be written (Object[])
    //    Map<String, Object[]> data = new TreeMap<String, Object[]>();
    //    data.put("1", new Object[] {"ID", "NAME", "LASTNAME"});
    //    data.put("2", new Object[] {1, "Amit", "Shukla"});
    //    data.put("3", new Object[] {2, "Lokesh", "Gupta"});
    //    data.put("4", new Object[] {3, "John", "Adwards"});
    //    data.put("5", new Object[] {4, "Brian", "Schultz"});
         
    //    //Iterate over data and write to sheet
    //    Set<String> keyset = data.keySet();
    //    int rownum = 0;
    //    for (String key : keyset)
    //    {
    //        Row row = sheet.createRow(rownum++);
    //        Object [] objArr = data.get(key);
    //        int cellnum = 0;
    //        for (Object obj : objArr)
    //        {
    //           Cell cell = row.createCell(cellnum++);
    //           if(obj instanceof String)
    //                cell.setCellValue((String)obj);
    //            else if(obj instanceof Integer)
    //                cell.setCellValue((Integer)obj);
    //        }
    //    }
    //    try
    //    {
    //        //Write the workbook in file system
    //        FileOutputStream out = new FileOutputStream(new File("howtodoinjava_demo.xls"));
    //        workbook.write(out);
    //        out.close();
    //        System.out.println("howtodoinjava_demo.xlsx written successfully on disk.");
    //    } 
    //    catch (Exception e) 
    //    {
    //        e.printStackTrace();
    //    }
	}

}
