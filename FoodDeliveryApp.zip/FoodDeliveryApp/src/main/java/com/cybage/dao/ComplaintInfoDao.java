package com.cybage.dao;

import org.springframework.data.jpa.repository.JpaRepository;

import com.cybage.model.ComplaintInfo;

public interface ComplaintInfoDao extends JpaRepository<ComplaintInfo, Integer>{
	
	 

}
