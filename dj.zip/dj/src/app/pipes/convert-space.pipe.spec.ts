import { ConvertSpacePipe } from './convert-space.pipe';

describe('ConvertSpacePipe', () => {
  it('create an instance', () => {
    const pipe = new ConvertSpacePipe();
    expect(pipe).toBeTruthy();
  });
});
