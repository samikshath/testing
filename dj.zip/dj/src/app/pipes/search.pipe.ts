import { Pipe, PipeTransform } from '@angular/core';
import { ITutorial } from '../utility/ITutorial';

@Pipe({
  name: 'searchPipe'
})
export class SearchPipe implements PipeTransform {

  // transform(value: any, ...args: any) {
  //   if(!value) return null;
  //   if(!args) return null;
  //   return value.filter(function(data:any){
  //     return JSON.stringify(data).includes(args);
  //   });

  // }



  transform(value: ITutorial[], args: string): any {
    if(!value) return null;
    if(!args) return value;

    let searchPipe=args.toLowerCase();
    return value.filter(tutorial=>{
      let tutorialName=tutorial.tutorialName.toLowerCase();
      return tutorialName.indexOf(searchPipe) !==-1;
    });
  }

}
