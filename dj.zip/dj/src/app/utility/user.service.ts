import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class UserService {

  constructor(private _HttpClient: HttpClient) { }


  getusers(): Observable<any> {
    return this._HttpClient.get<any>("http://localhost:8080/tutorial/");
  }

  // addUser():Observable<any>{
  //   return this._HttpClient.post<any>("http://localhost:8080/tutorial/",{"tutorialId": 8, "tutorialName": "hfghfh", "description": "gg gffg"});
  // }


  addUser(tutorial: any): Observable<any> {
    return this._HttpClient.post<any>("http://localhost:8080/tutorial/", tutorial);
  }

  deleteUser(): Observable<any> {
    return this._HttpClient.delete<any>("http://localhost:8080/tutorial/500");
  }

  // deleteUser(tutorialId:any): Observable<any> {
  //   return this._HttpClient.delete<any>("http://localhost:8080/tutorial/{tutorialId}");
  // }


  editUser(): Observable<any> {
    return this._HttpClient.put<any>("http://localhost:8080/tutorial/105", { "tutorialId": 105, "tutorialName": "zzzzzzz", "description": "aaaaa" });
  }

}
