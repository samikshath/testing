export interface ITutorial {
    tutorialId: number;
    tutorialName: string;
    description: string;
    img: string;
}