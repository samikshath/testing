import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { HeaderComponent } from './components/header/header.component';
import { FooterComponent } from './components/footer/footer.component';
import { TestComponent } from './components/test/test.component';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { TutorialListComponent } from './components/tutorial-list/tutorial-list.component';
import { ConvertSpacePipe } from './pipes/convert-space.pipe';
import { SearchPipe } from './pipes/search.pipe';
import { ChildComponent } from './components/child/child.component';
import { ParentComponent } from './components/parent/parent.component';
import { NavComponent } from './components/nav/nav.component';
import { TemplateDrivenFormComponent } from './components/template-driven-form/template-driven-form.component';
import { AddTutorialComponent } from './components/add-tutorial/add-tutorial.component';
import { HttpClientModule} from '@angular/common/http';
import { UserComponent } from './components/user/user.component';
import { GetTutorialComponent } from './components/get-tutorial/get-tutorial.component';

@NgModule({
  declarations: [
    AppComponent,
    HeaderComponent,
    FooterComponent,
    TestComponent,
    TutorialListComponent,
    ConvertSpacePipe,
    SearchPipe,
    ChildComponent,
    ParentComponent,
    NavComponent,
    TemplateDrivenFormComponent,
    AddTutorialComponent,
    UserComponent,
    GetTutorialComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    FormsModule,
    ReactiveFormsModule,
    HttpClientModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
