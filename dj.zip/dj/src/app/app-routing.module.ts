import { Component, NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { AddTutorialComponent } from './components/add-tutorial/add-tutorial.component';
import { GetTutorialComponent } from './components/get-tutorial/get-tutorial.component';
import { TutorialListComponent } from './components/tutorial-list/tutorial-list.component';

const routes: Routes = [
  { path: "getAllTutorial", component: TutorialListComponent },
  { path: "getTutorials", component: GetTutorialComponent },
  { path: "addTutorials", component: AddTutorialComponent }
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
