import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.scss']
})
export class AppComponent {
  title = 'Tutorial-App';

  message: string = "Hello from Angular"

  date:Date=new Date();

  amount:number=150;

  
  sayhello() {
    alert("Hello from angular");
  }

  msg:string="Some Text";

  show:boolean=true;

  num:string="num"
}
