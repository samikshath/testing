import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-test',
  template: `
    <p>
      {{msg}}
    </p>
  `,
  styles: [
  ]
})
export class TestComponent implements OnInit {

  msg:string="Hello......."
  constructor() { }

  ngOnInit(): void {
  }

}
