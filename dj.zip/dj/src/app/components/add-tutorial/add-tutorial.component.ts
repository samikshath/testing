// import { Component, OnInit } from '@angular/core';
// import { FormBuilder, FormControl, FormGroup, NgForm, Validators } from '@angular/forms';

// @Component({
//   selector: 'app-add-tutorial',
//   templateUrl: './add-tutorial.component.html',
//   styleUrls: ['./add-tutorial.component.scss']
// })
// export class AddTutorialComponent implements OnInit {

//   // tutorialForm:FormGroup=new FormGroup(
//   //   {
//   //     tutorialID:new FormControl(1),
//   //     tutorialName:new FormControl(''),
//   //     description:new FormControl(''),
//   //     img:new FormControl('')
    
//   //   }
//   // );

//   tutorialForm:FormGroup=this.fb.group({          //FORM-BUILDER
//     tutorialId:['',[Validators.required,Validators.min(100)]],
//     tutorialName:[''],
//     description:[''],
//     img:['']
//   })
  
//   constructor(private fb:FormBuilder,private _userService:UserService) { }

//   ngOnInit(): void {
//   }
 
  // onSubmit(){
   
  //   this._userService.addUser(this.addTutorialForm.value).subscribe(data=>console.log(data));

  // }

// }






import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { UserService } from 'src/app/utility/user.service';

@Component({
  selector: 'app-add-tutorial',
  templateUrl: './add-tutorial.component.html',
  styleUrls: ['./add-tutorial.component.scss']
})
export class AddTutorialComponent implements OnInit {

 

  constructor(private fb:FormBuilder , private _userService:UserService) { }

  ngOnInit(): void {
    
  }

  addTutorialForm:FormGroup=this.fb.group({
    tutorialId: ['' , [Validators.required , Validators.min(100)]],
    tutorialName: [''],
    description: ['']
  });

  // addTutorialForm : FormGroup= new FormGroup({
  //   tutorialId: new FormControl(1 , [Validators.required , Validators.min(100)]),
  //   tutorialName: new FormControl(''),
  //   description: new FormControl(''),
  //   img: new FormControl('')

  // });

  onSubmit(){
   
    this._userService.addUser(this.addTutorialForm.value).subscribe(data=>console.log(data));

  }
}
