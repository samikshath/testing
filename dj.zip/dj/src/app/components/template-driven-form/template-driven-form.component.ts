import { Component, OnInit } from '@angular/core';
import { NgForm } from '@angular/forms';

@Component({
  selector: 'app-template-driven-form',
  templateUrl: './template-driven-form.component.html',
  styleUrls: ['./template-driven-form.component.scss']
})
export class TemplateDrivenFormComponent implements OnInit {

  user={
    "firstName":"leela",
    "lastName":"lele"
  };

  constructor() { }

  ngOnInit(): void {
  }

  onSubmit(userForm:NgForm){
    console.log(userForm.value);
  }
}
