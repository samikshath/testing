import { Component, EventEmitter, Input, OnChanges, OnInit, Output, SimpleChanges } from '@angular/core';

@Component({
  selector: 'app-child',
  templateUrl: './child.component.html',
  styleUrls: ['./child.component.scss']
})
export class ChildComponent implements OnInit, OnChanges {


  @Input() count: number = 0;

  @Output() increment:EventEmitter<number>=new EventEmitter<number>()

  constructor() { }

  ngOnInit(): void {
    console.log("count :" + this.count);
  }
  ngOnChanges(changes: SimpleChanges): void {
    console.log("ngOnChanges...")
  }

  incrementCount(){
    this.increment.emit(++this.count);
  }
}
