import { ComponentFixture, TestBed } from '@angular/core/testing';

import { GetTutorialComponent } from './get-tutorial.component';

describe('GetTutorialComponent', () => {
  let component: GetTutorialComponent;
  let fixture: ComponentFixture<GetTutorialComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ GetTutorialComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(GetTutorialComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
