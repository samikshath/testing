import { Component, OnInit } from '@angular/core';
import { UserService } from 'src/app/utility/user.service';

@Component({
  selector: 'app-get-tutorial',
  templateUrl: './get-tutorial.component.html',
  styleUrls: ['./get-tutorial.component.scss']
})
export class GetTutorialComponent implements OnInit {

  tutorials: any;

  constructor(private _userService: UserService) { }

  ngOnInit(): void {
    this._userService.getusers().subscribe(data => { this.tutorials = data });
  }

  // ngOnClick(): void {
  //   this._userService.deleteUser(this.tutorials.tutorialId).subscribe(data => { this.tutorials.tutorialId = data });
  // }

}
