import { Component, OnInit } from '@angular/core';
import { ITutorial } from 'src/app/utility/ITutorial';

@Component({
  selector: 'app-tutorial-list',
  templateUrl: './tutorial-list.component.html',
  styleUrls: ['./tutorial-list.component.scss']
})
export class TutorialListComponent implements OnInit {

  tutorialList:ITutorial[] = [
    {
      tutorialId: 1, tutorialName: "Java", description: "Java Tutorial", img: "../assets/images/java.png"
    },
    {
      tutorialId: 2, tutorialName: "DotNet", description: "dotNet Tutorial", img: "../assets/images/.net.jfif"
    },
    {
      tutorialId: 3, tutorialName: "Php", description: "php Tutorial", img: "../assets/images/py.png"
    },
    {
      tutorialId: 4, tutorialName: "Python", description: "python Tutorial", img: "../assets/images/php1.jpg"
    }
  ];

  searchBy:string="";
  constructor() {
    console.log("constructor");
   }

  ngOnInit(): void {
    console.log("ngOninit....");
  }

}
